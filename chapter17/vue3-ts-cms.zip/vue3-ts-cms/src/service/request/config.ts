// const BASE_URL = 'http://httpbin.org' //  基础的URL
// const TIME_OUT = 10000 // 超时时间

const BASE_URL = process.env.VUE_APP_BASE_URL //  基础的URL
const TIME_OUT = 10000 // 超时时间
export { BASE_URL, TIME_OUT }
