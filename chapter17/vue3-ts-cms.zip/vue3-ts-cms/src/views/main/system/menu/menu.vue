<template>
  <div class="menu">
    <h2>menu 菜单</h2>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped lang="less"></style>
