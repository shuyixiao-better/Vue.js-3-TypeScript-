<template>
  <div class="department">
    <h2>department 部门</h2>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped lang="less"></style>
