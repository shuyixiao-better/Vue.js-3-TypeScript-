<template>
  <div class="role">
    <h2>role 角色</h2>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped lang="less"></style>
