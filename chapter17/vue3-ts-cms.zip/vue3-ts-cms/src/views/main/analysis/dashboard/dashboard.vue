<template>
  <div class="dashboard">
    <h2>dashboard 商品统计</h2>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped lang="less"></style>
