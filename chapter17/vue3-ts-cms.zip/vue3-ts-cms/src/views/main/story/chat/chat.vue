<template>
  <div class="chat">
    <h2>chat</h2>
  </div>
</template>
